
$(document).ready(function() {
	//点击按钮下滑到注册页面
	$(".teimgdd").bind("click",function(e){
		e.defaultPrevented();
		$(".lbaregismain").animate({top:'-11rem'},300);
	});
	//下滑页面到页面最顶端
	var windowTop = 0; //初始话可视区域距离页面顶端的距离
	$(window).scroll(function() {
		var scrolls = $(this).scrollTop(); //获取当前可视区域距离页面顶端的距离
		if(scrolls >= windowTop) { //当B>A时，表示页面在向下滑动
			$(".lbaregismain").animate({top:'0rem'},300);
		}
	});

	$(".lbacodimgr>img").attr("src",adressurl.one.uri+"common/authCode.do?abc=%27+Math.random");

	/*手机输入框中     非数字就自动删除*/
	$("#lbaregtelk,#lbaregtelcodk,#lbaregtelcodimg").keyup(function(){
		$("#lbamessageout").text("");
		$(".lbacodf label").text("");
		var numval=$(this).val();
		if(isNaN(numval)){
		   $(this).val($(this).val().replace(/\D|^0/g,''));  
		}
		var num = $("#lbaregtelk").val().substr(0, 11);
		$("#lbaregtelk").val(num);
		var lbaregtelcodkva=$("#lbaregtelcodk").val().substr(0,6);
		$("#lbaregtelcodk").val(lbaregtelcodkva);
		var lbaregtelcodkvaimg=$("#lbaregtelcodimg").val().substr(0,4);
		$("#lbaregtelcodimg").val(lbaregtelcodkvaimg);

	});
	//已经是会员页面的关闭按钮
	$(".mebredclo").click(function(){
		$(".memberready").addClass("curdis");
	});
	//页面底部下载关闭按钮
	$(".lrgclose").click(function(){
		$(".lbargbm").addClass("curdis");
	});
	/*表单验证*/
    var validatorCode = $("#lbaform").validate({
        rules: {
          lbaregtel: {
              required:true,
             isMobile: true
          },
            lbacodeimg: {
                required:true,
                number:true
            }
        }
    });
    var validator = $("#lbaform").validate({
        rules: {
            lbaregtel: {
                required:true,
                isMobile: true
            }
        }
    });
	/*发送验证码*/
	$('.lbacodr').on('click',function (){
		if (validatorCode.form()){
			$("#lbamessageout").text("");
			$(".lbacodr").addClass("disabled");
			var phoneNum = $("#lbaregtelk").val();
			 var lbacodimg=$("#lbaregtelcodimg").val();
			var data1 = {"parameters": "{\"authCode\":\""+lbacodimg+"\",\"username\":\""+phoneNum+"\",\"type\":\"1\"}"};
			$.ajax({
	            type: "POST", 
	            dataType: "jsonp", 
	            jsonp:"callback",
	            jsonpCallback:"jsonpCallback",
	            url:adressurl.one.uri+"User/getIdentifyingCode/ajax",
				data: data1,
				success: function(data){
					if (data.message=="该手机号已经注册过") {
						$("#lbamessageout").text(data.message);
						$(".lbaregtel label").addClass("curdis");
						$(".lbaregcodv label").addClass("curdis");
				    	$(".memberready").removeClass("curdis");
				    	$(".lbacodr").removeClass("disabled");
				    }else if(data.message=="一小时内最多获取三次验证码"){
				    	$("#lbamessageout").text(data.message);
				    	$(".lbaregtel label").addClass("curdis");
						$(".lbaregcodv label").addClass("curdis");
				    }else if(data.msg=="图形验证码校验失败！"){
				    	$(".lbacodr").removeClass("disabled");
				    	$("#lbamessageout").text(data.msg);
				    	$(".lbacodimgr>img").attr("src",adressurl.one.uri+"common/authCode.do?abc=%27+Math.random" + new Date().getTime());
				    }else{
                        $("#lbamessageout").text(data.message);
                        $("#lbamessageout").text(data.msg);
                        $(".lbaregtel label").addClass("curdis");
						$(".lbaregcodv label").addClass("curdis");
				    	time($('.lbacodr')[0]);
				    }
				}
			});
		}
		
	});
	//判断安卓 or  ios
	var u = navigator.userAgent;
	var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
	var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	var registPlatform; 
	var channel;
	var channelres = getQueryString('channel');//获取地址栏channel的值
	if (isAndroid==true) {
		
		if(channelres==null){
			registPlatform=1;
		    channel="000";
		}else{
			registPlatform=1;
		    channel=channelres;
		}
	}else{
		if(channelres==null){
			registPlatform=2;
		    channel=2;
		}else{
			registPlatform=2;
		    channel=channelres;
		}
		
	};
	/*注册*/
	$('.regsumit').on('click',function (){
		$("#lbamessageout").text("");
		var lbaregid = getQueryString('p');
		if(lbaregid==null){
			lbaregid="";
		}
		if (validator.form()){
			var phoneNum = $("#lbaregtelk").val();
            var lbacod=$("#lbaregtelcodk").val();
          var data2 = {"parameters": "{\"username\":\""+phoneNum+"\",\"phoneId\":\"\",\"code\":\""+lbacod+"\",\"registPlatform\":\""+registPlatform+"\",\"channel\":\""+channel+"\",\"inviteId\":\""+lbaregid+"\",\"type\":\"0\"}"};
			$.ajax({
				url:adressurl.one.uri+"User/quick/register.do",
				type: 'post',
				data: data2,
				dataType: 'jsonp',
				jsonp: 'callback',
				jsonpCallback:"jsonpCallback",
				success : function(data){
					console.log(data);
					console.log(data.message);
					if(data.end=="ok"){
						window.location="regist-success.html";
					}else if(data.message=="该手机号已经注册过"){
						$("#lbamessageout").text(data.message);
						$(".lbaregtel label").addClass("curdis");
						$(".lbaregcodv label").addClass("curdis");
				    	$(".memberready").removeClass("curdis");
				    	$(".lbacodr").removeClass("disabled");
					}else{
						$("#lbamessageout").show().text(data.message);
					}
				 }
			});
		}else{
			$("#lbamessageout").text("请正确完整填写信息");
			console.log('error');
		}
	});
/*倒计时*/
	var wait=60;
	function time(o) {
		
	    if (wait == 0) {
	        o.removeAttribute("disabled");
	        o.innerHTML="重新获取";
	        $(".lbacodr").removeClass("disabled");
	        wait = 60;
	    } else {
	        o.setAttribute("disabled", true);
	        o.innerHTML=wait+"s";
	        wait--;
	        setTimeout(function() {
	                time(o)
	            },
	            1000)
	    }
	}
	$(".lbacodr,.regsumit").click(function(){
		
		$("#lbamessageout").text("");
		var telval=$("#lbaregtelk").val();
		
		if($(".lbaregtel label").attr("style")){
			$("#lbamessageout").text("");
		}else if(telval.length>10){
			var imglab=$(".lbacodimg>div label").text();
			$("#lbamessageout").text("");
			$("#lbamessageout").text(imglab);
		}
		
		if($(".lbaregtel label").css("display")=='none'){
			var imglab=$(".lbacodimg>div label").text();
			$("#lbamessageout").text("");
			$("#lbamessageout").text(imglab);
		}
		
	});

});